<?php
$conn = mysqli_connect('localhost','root','','e_passport') or die('connection failed');
?>